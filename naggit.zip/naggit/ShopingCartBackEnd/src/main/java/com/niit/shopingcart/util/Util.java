package com.niit.shopingcart.util;

public class Util {
	 public String replace(String s,String se, String set){
		 return s.replace(se, set);
	 }

}
