package com.niit.collab.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import java.sql.Date;

import javax.persistence.Column;

@Entity
@Table(name="Blogs")
public class Blogs {
@Id
@GeneratedValue(strategy= GenerationType.IDENTITY)
@Column
private int bl_id;

@NotEmpty(message="Blog content cannot be empty")
private String bl_content;

@NotEmpty(message="Blog username cannot be empty")
private String bl_username;


@NotEmpty(message="Blog creation time cannot be empty")
private Date createtimestamp;


public int getBl_id() {
	return bl_id;
}


public void setBl_id(int bl_id) {
	this.bl_id = bl_id;
}


public String getBl_content() {
	return bl_content;
}


public void setBl_content(String bl_content) {
	this.bl_content = bl_content;
}


public String getBl_username() {
	return bl_username;
}


public void setBl_username(String bl_username) {
	this.bl_username = bl_username;
}


public Date getCreatetimestamp() {
	return createtimestamp;
}


public void setCreatetimestamp(Date createtimestamp) {
	this.createtimestamp = createtimestamp;
}

}
