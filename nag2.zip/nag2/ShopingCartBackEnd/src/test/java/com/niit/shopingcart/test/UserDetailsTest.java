package com.niit.shopingcart.test;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.shopingcart.dao.UserDetailsDAO;
import com.niit.shopingcart.model.UserDetails;

public class UserDetailsTest {
	
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
	UserDetails u =(UserDetails)	  context.getBean("userDetails");
	
	UserDetailsDAO userDAO = (UserDetailsDAO)  context.getBean("userDAO");
	

	u.setId(3);
	u.setName("niit");
	u.setPassword("niit");
	u.setMobile("9123654781");
	u.setEmail("niit@gmail.com");
	u.setAddress("Hyd");
	
	userDAO.saveOrUpdate(u);

	}

}
