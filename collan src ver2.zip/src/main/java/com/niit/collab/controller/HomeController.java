package com.niit.collab.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController
{
	

	
	@RequestMapping("/")
	public ModelAndView HomePages()
	{
			System.out.println("I am in Controller");
			return new ModelAndView("Home");
			
	}

}
