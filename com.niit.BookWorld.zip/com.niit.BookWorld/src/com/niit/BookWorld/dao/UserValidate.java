package com.niit.BookWorld.dao;

public class UserValidate {
	
	public boolean isValid(String user,String pwd){
		
		if(user.equals("user")&& pwd.equals("user"))
		{
			return true;
			
		}
		
			return false;
		
		}
	}


